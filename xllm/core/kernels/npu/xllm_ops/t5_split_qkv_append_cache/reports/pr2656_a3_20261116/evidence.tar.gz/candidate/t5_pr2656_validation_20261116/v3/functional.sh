#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
set -euo pipefail
[[ $# == 3 ]] || { echo 'Usage: functional.sh REPOSITORY EXACT_COMMIT smoke|correctness'; exit 2; }
mode="$3"
case "$mode" in smoke|correctness) ;; *) exit 2 ;; esac
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh" "$1" "$2"
if [[ "$mode" == smoke ]]; then phase_begin smoke build; else phase_begin correctness smoke; fi
phase_device_inventory selected
if [[ "$mode" == smoke ]]; then
 for name in cpp_smoke_fp16.log cpp_smoke_bf16.log aclnn_invalid_metadata.log smoke_stability.json; do [[ ! -e "reports/$name" ]] || exit 2; done
 build/examples/t5_example > reports/cpp_smoke_fp16.log 2>&1
 build/examples/t5_example --bf16 > reports/cpp_smoke_bf16.log 2>&1
 build/examples/t5_example --negative > reports/aclnn_invalid_metadata.log 2>&1
 python - <<'PY'
import json, math
from pathlib import Path
import torch, torch_npu
import generate_data, golden, solution, verify
from scripts.logger import logger
for name in ('cpp_smoke_fp16.log','cpp_smoke_bf16.log'):
    rows = [json.loads(line) for line in (Path('reports')/name).read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 1 and rows[0] == {'status':'passed','workspace_bytes':0,'bit_mismatches':0}
rows = [json.loads(line) for line in Path('reports/aclnn_invalid_metadata.log').read_text().splitlines() if line.startswith('{')]
assert len(rows) == 5 and {row['metadata_scenario'] for row in rows} == set(range(5))
assert all(row['status'] == 'passed' and row['acl_status'] != 0 for row in rows)
torch.npu.set_device(0)
cases = json.loads(Path('reference/case.json').read_text())
selected, records = [], []
for dtype in ('float16','bfloat16'):
    matching = [case for case in cases if case['input_desc'][0]['data_type'] == dtype]
    selected += [matching[0], max(matching,key=lambda case:math.prod(case['input_desc'][1]['shape']))]
for case in selected:
    arrays = generate_data.generate(case)
    attrs = {attr['name']:attr['value'] for attr in case['attr_desc']}
    inputs = verify.device_inputs(case,arrays,'npu:0')
    expected = golden.calculate(arrays,attrs)
    for entry in ('run','run_direct'):
        for repeat in range(20):
            output = getattr(solution,entry)(inputs,attrs)
            torch.npu.synchronize()
            verify.validate_ownership(inputs,output)
            verify.compare(case,arrays,output,expected)
        record = {'case_name':case['case_name'],'entry':entry,'repeats':20,'status':'passed'}
        records.append(record)
        logger.info(record)
assert len(records) == 8
with Path('reports/smoke_stability.json').open('x') as target:
    json.dump({'status':'passed','npu_executed':True,'records':records},target,indent=2); target.write('\n')
PY
else
 for name in public_accuracy extended_accuracy engineering memory; do [[ ! -e "reports/$name.json" && ! -e "reports/$name.log" ]] || exit 2; done
 python reference/verify.py --device 0 --solution-file "$TASK_ROOT/solution.py" --report reports/public_accuracy.json > reports/public_accuracy.log 2>&1
 python tests/npu_suite.py --device 0 --group accuracy --report reports/extended_accuracy.json > reports/extended_accuracy.log 2>&1
 python tests/npu_suite.py --device 0 --group engineering --report reports/engineering.json > reports/engineering.log 2>&1
 python tests/npu_suite.py --device 0 --group memory --report reports/memory.json > reports/memory.log 2>&1
 python - <<'PY'
import json, os
from pathlib import Path
counts = {}
requirements = json.loads(Path('reference/coverage_requirements.json').read_text())
for name, key, count in [('public_accuracy','cases',35),('extended_accuracy','records',150),('engineering','records',15),('memory','records',20)]:
    report = json.loads(Path('reports',name+'.json').read_text())
    assert report['status'] == 'passed' and report['npu_executed'] is True, name
    rows = report[key]
    assert len(rows) == count, (name,len(rows),count)
    keys = {(row['case_name'],row.get('entry','run')) for row in rows}
    assert len(keys) == count and all(row.get('status','passed') == 'passed' for row in rows), name
    if name == 'public_accuracy':
        assert keys == {(case,'run') for case in requirements['public_cases']}
    if name == 'memory':
        assert keys == {(case,entry) for case in requirements['performance_case_ids'] for entry in ('run','run_direct')}
        for row in rows:
            assert row['workspace_bytes'] == 0 and row['peak_increment'] <= row['output_bytes']+16384
            assert len(row['after_each_release']) == 20 and all(value == row['before'] for value in row['after_each_release'])
    counts[name] = count
with Path(os.environ['T5_EVIDENCE'],'functional_summary.json').open('x') as output:
    json.dump({'status':'passed','source_commit':os.environ['T5_COMMIT'],'counts':counts,'npu_executed':True},output,indent=2); output.write('\n')
print(json.dumps(counts))
PY
fi

#!/usr/bin/env bash
set -euo pipefail
ops=/workspace/t5_pr2656_validation_20261116
cd "$ops"
[[ ! -e "$ops/pipeline_cbe5ac66.exit" ]] || { echo 'Preserve prior result'; exit 2; }
mkdir "$ops/pipeline_cbe5ac66.lock"
trap 'rc=$?; (set -o noclobber; printf "%s\n" "$rc" > "$ops/pipeline_cbe5ac66.exit"); exit "$rc"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
python3 restore_chunked_archive.py xllm_pr2656_cbe5ac665188.transfer.json 5f9a725b3f5ac9a84a53f03977b9a2ce9b04daebe036eaa352cb109f8e35be0e
python3 deploy_exact_sources.py xllm_pr2656_cbe5ac665188.tar xllm_pr2656_cbe5ac665188.manifest.json \
 --expected-commit cbe5ac665188298435b25ce1b36a3ece252ef769 \
 --manifest-sha256 35d3b95815305854ef59d2eed9eb3177af0ef55630eca87bf4afd7ad88348792
python3 host_kernel/run_host_kernel.py \
 --project-root /workspace/t5_qkv_tasks/xllm_pr2656_cbe5ac665188 \
 --expected-kernel-sha256 e31fab4775acacdfb417ad55dc3fef6fce90b62e5af28b479b16cbb7c14d8dad \
 --expected-plan-sha256 dbd72a9b9585df82f83852342168237e19df73e8c7bbe29238477d07c8f93c6c \
 --reference-counts host_kernel/a201_reference_counts.json \
 --report-dir /workspace/t5_pr2656_validation_20261116/host_port_cbe5ac66
cd v3
sha256sum --check --strict WRAPPER_SHA256SUMS.txt
for script in common.sh build.sh functional.sh performance.sh launch.sh environment_probe.sh; do bash -n "$script"; done
export ASCEND_RT_VISIBLE_DEVICES=1 T5_PHYSICAL_DEVICE=3
export T5_DEVICE_CONFIRMED=1 T5_ACCEPTED_DRIVER=26.1.1 T5_BUILD_JOBS=4
root=/workspace/t5_qkv_tasks/xllm_pr2656_cbe5ac665188
commit=cbe5ac665188298435b25ce1b36a3ece252ef769
bash launch.sh "$root" "$commit" probe
bash launch.sh "$root" "$commit" build
bash launch.sh "$root" "$commit" smoke
bash launch.sh "$root" "$commit" correctness
bash launch.sh "$root" "$commit" fixed
bash launch.sh "$root" "$commit" baseline
bash launch.sh "$root" "$commit" stability

#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
# External operational wrapper; exact component/dependency archive, existing venv only.
[[ $# == 2 ]] || { echo 'Expected REPOSITORY_DIRECTORY EXACT_COMMIT' >&2; exit 2; }
: "${ASCEND_HOME_PATH:?Load the verified CANN 9.1.0 environment first}"
T5_REPO=$(realpath -e -- "$1")
T5_COMMIT="$2"
[[ "$T5_COMMIT" =~ ^[0-9a-f]{40}$ ]] || exit 2
[[ $(basename -- "$T5_REPO") == "xllm_pr2656_${T5_COMMIT:0:12}" ]] || exit 2
T5_WRAPPERS=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
TASK_ROOT="$T5_REPO/xllm/core/kernels/npu/xllm_ops/t5_split_qkv_append_cache"
TASK_VENV=/workspace/t5_qkv_tasks/venv_t5_py312_torch210_20261116_offline_v3
T5_OPP_ROOT="$HOME/.local/xllm_pr2656_${T5_COMMIT:0:12}"
T5_EVIDENCE="$TASK_ROOT/artifacts/pr2656_validation_v3"
export T5_REPO T5_COMMIT T5_WRAPPERS TASK_ROOT TASK_VENV T5_OPP_ROOT T5_EVIDENCE
export VIRTUAL_ENV="$TASK_VENV" PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
: "${T5_CANN_ENVIRONMENT_SNAPSHOT:?Use v3 launch.sh so the official CANN environment is retained and recorded}"
# Keep the entire official environment. Only prepend task-specific search paths.
export PATH="$TASK_VENV/bin:$PATH"
T5_CANN_PYTHON_SITE=$(realpath -e -- "$ASCEND_HOME_PATH/python/site-packages")
T5_CANN_TBE_SITE=$(realpath -e -- "$ASCEND_HOME_PATH/opp/built-in/op_impl/ai_core/tbe")
export T5_CANN_PYTHON_SITE T5_CANN_TBE_SITE
export PYTHONPATH="$T5_REPO:$TASK_ROOT:$TASK_ROOT/reference${PYTHONPATH:+:$PYTHONPATH}"
export ASCEND_CUSTOM_OPP_PATH="$T5_OPP_ROOT/vendors/t5qkv"
export LD_LIBRARY_PATH="$TASK_ROOT/build/direct/lib:$T5_OPP_ROOT/vendors/t5qkv/op_api/lib:$TASK_VENV/lib/python3.12/site-packages/torch/lib:$TASK_VENV/lib/python3.12/site-packages/torch_npu/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export MAX_JOBS="${T5_BUILD_JOBS:-4}"
[[ "$MAX_JOBS" =~ ^[1-9][0-9]*$ ]] || exit 2
export T5_BUILD_JOBS="$MAX_JOBS"
cd "$TASK_ROOT"

verify_source() {
 "$TASK_VENV/bin/python" -I - <<'PY'
import hashlib, importlib.metadata as metadata, json, os, sys
from pathlib import Path, PurePosixPath
repo, root, venv = (Path(os.environ[key]) for key in ('T5_REPO','TASK_ROOT','TASK_VENV'))
commit = os.environ['T5_COMMIT']
assert Path(sys.prefix).resolve() == venv
assert (venv/'setup.exit').read_bytes() == b'0\n'
receipt = json.loads((venv/'metadata_verified.json').read_text())
assert receipt['status'] == 'pinned_metadata_verified_no_device_execution'
assert receipt['torch_npu_git_version'].startswith('5dd8ef3') and receipt['npu_executed'] is False
for name, version in {'torch':'2.10.0+cpu','torch-npu':'2.10.0.post4','numpy':'2.2.6','ml-dtypes':'0.6.0'}.items():
    dist = metadata.distribution(name)
    assert dist.version == version and Path(dist.locate_file('')).resolve().is_relative_to(venv)
raw = (repo/'DEPLOYMENT_MANIFEST.json').read_bytes()
manifest = json.loads(raw)
assert manifest['commit'] == commit and manifest['prefix'].rstrip('/') == repo.name
relative_component = root.relative_to(repo)
seen, component = set(), []
for item in manifest['files']:
    member = PurePosixPath(item['path'])
    assert not member.is_absolute() and '..' not in member.parts and member.parts
    relative = member.relative_to(manifest['prefix'].rstrip('/'))
    assert relative.parts
    assert relative.as_posix() not in seen
    seen.add(relative.as_posix())
    path = repo/relative.as_posix()
    assert path.resolve(strict=True).is_relative_to(repo) and path.is_file()
    data = path.read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], str(relative)
    if relative.is_relative_to(PurePosixPath(relative_component.as_posix())):
        entry = dict(item)
        entry['path'] = root.name+'/'+relative.relative_to(relative_component.as_posix()).as_posix()
        component.append(entry)
assert 'scripts/logger.py' in seen and component
assert root.parents[5] == repo, 'Keep the full xLLM repository hierarchy'
# Existing fingerprint.py expects its manifest at the component root.
projection = {'commit':commit, 'prefix':root.name, 'files':component,
              'repository_root':str(repo), 'repository_manifest_sha256':hashlib.sha256(raw).hexdigest()}
target = root/'DEPLOYMENT_MANIFEST.json'
if target.exists():
    assert json.loads(target.read_text()) == projection, 'Projection differs from exact repository archive'
else:
    with target.open('x') as output:
        json.dump(projection, output, indent=2); output.write('\n')
print(json.dumps({'source_commit':commit,'repository_files_verified':len(seen),'component_files_verified':len(component)}))
PY
}

verify_binaries() {
 "$TASK_VENV/bin/python" -I - <<'PY'
import hashlib, json, os
from pathlib import Path
root, opp = Path(os.environ['TASK_ROOT']), Path(os.environ['T5_OPP_ROOT'])
record = json.loads((Path(os.environ['T5_EVIDENCE'])/'binary_manifest.json').read_text())
assert record['source_commit'] == os.environ['T5_COMMIT'] and record['private_opp'] == str(opp)
expected = {root/'build/direct/lib/libt5_direct.so', root/'build/examples/t5_example'}
extensions = list(root.glob('_t5_qkv*.so'))
assert len(extensions) == 1
expected.update(extensions)
expected.update(path for path in opp.rglob('*') if path.is_file() and path.suffix in {'.so','.o','.json','.h'})
seen = set()
for item in record['files']:
    path = Path(item['path'])
    assert path in expected and path not in seen
    data = path.read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], str(path)
    seen.add(path)
assert seen == expected
PY
}

verify_msopgen_environment() {
 local msopgen_binary msopgen_python
 msopgen_binary=$(command -v msopgen)
 msopgen_python=$("$TASK_VENV/bin/python" -I - "$msopgen_binary" <<'PY'
import shlex, sys
from pathlib import Path
first = Path(sys.argv[1]).read_bytes().splitlines()[0].decode('utf-8')
assert first.startswith('#!'), 'msopgen has no interpreter shebang'
parts = shlex.split(first[2:])
assert len(parts) == 1 and Path(parts[0]).is_absolute() and Path(parts[0]).is_file(), first
print(parts[0])
PY
 )
 # Match the actual CLI interpreter while preserving the explicit CANN PYTHONPATH.
 "$msopgen_python" -s - "$msopgen_binary" <<'PY' > "$T5_EVIDENCE/${T5_PHASE}_msopgen_import.json"
import json, os, sys
from pathlib import Path
from msopgen.interface import arg_parser
site = Path(os.environ['T5_CANN_PYTHON_SITE'])
tbe = Path(os.environ['T5_CANN_TBE_SITE'])
module = Path(arg_parser.__file__).resolve(strict=True)
assert module.is_relative_to(site), 'msopgen resolved outside the selected CANN installation'
paths = {str(Path(item).resolve()) for item in sys.path if item}
assert str(site) in paths and str(tbe) in paths
print(json.dumps({'status':'passed','msopgen_command':sys.argv[1],
                  'shebang_python':sys.executable,'arg_parser':str(module),
                  'cann_python_site':str(site),'cann_tbe_site':str(tbe),
                  'PYTHONPATH':os.environ['PYTHONPATH'],'npu_executed':False}))
PY
 "$msopgen_binary" --help > "$T5_EVIDENCE/${T5_PHASE}_msopgen_help.log" 2>&1
}

verify_cann_environment() {
 "$TASK_VENV/bin/python" -I - <<'PY'
import hashlib, json, os
from pathlib import Path
snapshot_path = Path(os.environ['T5_CANN_ENVIRONMENT_SNAPSHOT'])
snapshot = json.loads(snapshot_path.read_text())
assert hashlib.sha256(Path(snapshot['source_script']).read_bytes()).hexdigest() == snapshot['source_script_sha256']
before = snapshot['environment']
root, venv, opp = (os.environ[key] for key in ('TASK_ROOT','TASK_VENV','T5_OPP_ROOT'))
prefixes = {'PATH':venv+'/bin', 'PYTHONPATH':os.environ['T5_REPO']+':'+root+':'+root+'/reference',
            'LD_LIBRARY_PATH':root+'/build/direct/lib:'+opp+'/vendors/t5qkv/op_api/lib:'+venv+'/lib/python3.12/site-packages/torch/lib:'+venv+'/lib/python3.12/site-packages/torch_npu/lib',
            'ASCEND_CUSTOM_OPP_PATH':opp+'/vendors/t5qkv'}
for key in sorted(set(before) | set(prefixes)):
    expected = before.get(key)
    if key in prefixes:
        expected = prefixes[key] + (':'+expected if expected else '')
    assert os.environ.get(key) == expected, 'Official environment changed beyond allowed prefix: '+key
assert before.get('CMAKE_PREFIX_PATH'), 'Official CMAKE_PREFIX_PATH is missing'
assert not before.get('ASCEND_CUSTOM_OPP_PATH'), 'Prior task custom OPP must be cleared before official set_env'
record = {'status':'all_recorded_official_build_variables_retained', 'source_commit':os.environ['T5_COMMIT'],
          'source_snapshot':str(snapshot_path),'snapshot_sha256':hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
          'allowed_prefixes':prefixes,'verified_keys':sorted(before),'npu_executed':False}
with (Path(os.environ['T5_EVIDENCE'])/(os.environ['T5_PHASE']+'_environment_retention.json')).open('x') as output:
    json.dump(record,output,indent=2); output.write('\n')
print(json.dumps(record))
PY
 # This is the non-isolated import search path actually used by build/tests.
 "$TASK_VENV/bin/python" - <<'PY'
import importlib.metadata as metadata, importlib.util, json, os, sys
from pathlib import Path
venv = Path(os.environ['TASK_VENV'])
assert Path(sys.prefix).resolve() == venv
expected = {'torch':'2.10.0+cpu','torch_npu':'2.10.0.post4','numpy':'2.2.6','ml_dtypes':'0.6.0'}
records = {}
for name, version in expected.items():
    distribution = metadata.distribution(name)
    spec = importlib.util.find_spec(name)
    assert distribution.version == version and Path(distribution.locate_file('')).resolve().is_relative_to(venv), name
    assert spec is not None and spec.origin is not None and Path(spec.origin).resolve().is_relative_to(venv), name
    records[name] = {'version':version,'origin':spec.origin}
with (Path(os.environ['T5_EVIDENCE'])/(os.environ['T5_PHASE']+'_python_resolution.json')).open('x') as output:
    json.dump({'status':'passed','isolated_mode':False,'packages':records,'npu_executed':False},output,indent=2); output.write('\n')
PY
}

verify_asc_config_resolution() {
 "$TASK_VENV/bin/python" -I - <<'PY'
import hashlib, json, os, re
from pathlib import Path
prefixes = [Path(value) for value in re.split('[:;]',os.environ['CMAKE_PREFIX_PATH']) if value]
configs = []
for prefix in prefixes:
    for directory in (prefix,prefix/'ASC',prefix/'asc'):
        for name in ('ASCConfig.cmake','asc-config.cmake'):
            path = directory/name
            if path.is_file() and str(path.resolve()) not in {record['path'] for record in configs}:
                configs.append({'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert configs, 'CMAKE_PREFIX_PATH does not resolve an ASC package configuration'
record = {'status':'config_file_resolution_only','source_commit':os.environ['T5_COMMIT'],
          'CMAKE_PREFIX_PATH':os.environ['CMAKE_PREFIX_PATH'],'configs':configs,
          'find_package_configure_executed':False,'operator_compiled':False,'npu_executed':False}
with (Path(os.environ['T5_EVIDENCE'])/(os.environ['T5_PHASE']+'_asc_config_resolution.json')).open('x') as output:
    json.dump(record,output,indent=2); output.write('\n')
print(json.dumps(record))
PY
 local probe_root="$T5_EVIDENCE/${T5_PHASE}_asc_find_package"
 mkdir "$probe_root"
 mkdir "$probe_root/source"
 cat > "$probe_root/source/CMakeLists.txt" <<'CMAKE'
cmake_minimum_required(VERSION 3.16)
project(t5_asc_probe LANGUAGES CXX)
find_package(ASC REQUIRED CONFIG)
CMAKE
 cmake -S "$probe_root/source" -B "$probe_root/build" \
   -DASCEND_COMPUTE_UNIT=ascend910_93 -DSOC_VERSION=Ascend910_9382 \
   -DCMAKE_BUILD_TYPE=Release -DRUN_MODE=npu > "$probe_root/configure.log" 2>&1
 "$TASK_VENV/bin/python" -I - "$probe_root" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
root = Path(sys.argv[1])
cache = {}
for line in (root/'build/CMakeCache.txt').read_text().splitlines():
    if line and not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
        key, value = line.split('=',1)
        cache[key.split(':',1)[0]] = value
configs = json.loads((root.parent/(os.environ['T5_PHASE']+'_asc_config_resolution.json')).read_text())['configs']
selected = [item for item in configs if Path(item['path']).parent == Path(cache['ASC_DIR']).resolve()]
assert len(selected) == 1, 'Configured ASC_DIR does not match verified official package'
assert Path(cache['CMAKE_CXX_COMPILER']).resolve() == Path('/usr/bin/c++').resolve()
snapshot = json.loads(Path(os.environ['T5_CANN_ENVIRONMENT_SNAPSHOT']).read_text())
record = {'status':'passed','source_commit':os.environ['T5_COMMIT'],
          'official_environment':snapshot['environment'], 'source_script_sha256':snapshot['source_script_sha256'],
          'effective_environment':{key:os.environ.get(key) for key in sorted(set(snapshot['environment']) | {'ASCEND_CUSTOM_OPP_PATH'})},
          'ASC_DIR':cache['ASC_DIR'],'CMAKE_CXX_COMPILER':cache['CMAKE_CXX_COMPILER'],
          'selected_config':selected[0],'find_package_configure_executed':True,
          'operator_compiled':False,'npu_executed':False,
          'configure_log_sha256':hashlib.sha256((root/'configure.log').read_bytes()).hexdigest()}
with (root.parent/(os.environ['T5_PHASE']+'_asc_configure.json')).open('x') as output:
    json.dump(record,output,indent=2); output.write('\n')
print(json.dumps({'status':'passed','ASC_DIR':cache['ASC_DIR'],'operator_compiled':False,'npu_executed':False}))
PY
}

phase_begin() {
 T5_PHASE="$1"
 local prerequisite="${2:-}"
 export T5_PHASE
 mkdir -p "$T5_EVIDENCE" reports
 if [[ -n "$prerequisite" ]]; then [[ $(cat "$T5_EVIDENCE/$prerequisite.exit") == 0 ]] || exit 2; fi
 [[ ! -e "$T5_EVIDENCE/$T5_PHASE.exit" && ! -e "$T5_EVIDENCE/$T5_PHASE.log" ]] || exit 2
 mkdir "$T5_EVIDENCE/$T5_PHASE.lock"
 T5_DEVICE_STARTED=0
 trap 'exit 143' TERM
 trap 'exit 130' INT
 trap phase_finish EXIT
 set -o noclobber
 exec > "$T5_EVIDENCE/$T5_PHASE.log" 2>&1
 set +o noclobber
 sha256sum -- "$T5_WRAPPERS/"*.sh "$T5_WRAPPERS/resolve_device_mapping.py" "$T5_REPO/DEPLOYMENT_MANIFEST.json"
 verify_cann_environment
 verify_source
 if [[ "$T5_PHASE" == environment_probe ]]; then
   verify_msopgen_environment
   verify_asc_config_resolution
 fi
 if [[ "$T5_PHASE" == build ]]; then
   "$TASK_VENV/bin/python" -I - <<'PY'
import hashlib, json, os
from pathlib import Path
folder = Path(os.environ['T5_EVIDENCE'])
assert (folder/'environment_probe.exit').read_bytes() == b'0\n', 'Run successful v3 environment probe first'
record = json.loads((folder/'environment_probe_asc_configure.json').read_text())
assert record['status'] == 'passed' and record['find_package_configure_executed'] is True
assert record['source_commit'] == os.environ['T5_COMMIT']
snapshot = json.loads(Path(os.environ['T5_CANN_ENVIRONMENT_SNAPSHOT']).read_text())
assert record['official_environment'] == snapshot['environment'], 'Official environment differs from successful probe'
assert record['source_script_sha256'] == snapshot['source_script_sha256']
assert all(os.environ.get(key) == value for key,value in record['effective_environment'].items()), 'Build environment differs from probe'
selected = record['selected_config']
assert hashlib.sha256(Path(selected['path']).read_bytes()).hexdigest() == selected['sha256']
PY
 fi
 python tools/preflight.py --static
 python tools/fingerprint.py --output "$T5_EVIDENCE/${T5_PHASE}_source_before.json"
}

phase_finish() {
 local rc=$? check_rc=0
 trap - EXIT
 set +e
 verify_source || check_rc=2
 if [[ -f "$T5_EVIDENCE/binary_manifest.json" ]]; then verify_binaries || check_rc=2; fi
 if [[ "$T5_DEVICE_STARTED" == 1 ]]; then
   python tools/preflight.py --output "$T5_EVIDENCE/${T5_PHASE}_environment_after.json" || check_rc=2
   npu-smi info > "$T5_EVIDENCE/${T5_PHASE}_device_after.txt" || check_rc=2
   npu-smi info -t proc-mem -i "$T5_CARD" -c "$T5_CHIP" > "$T5_EVIDENCE/${T5_PHASE}_selected_after.txt" || check_rc=2
   grep -Eq '^[[:space:]]*No process in device\.[[:space:]]*$' "$T5_EVIDENCE/${T5_PHASE}_selected_after.txt" || check_rc=2
   if [[ "$T5_DEVICE_SCOPE" == board ]]; then grep -q 'No running processes found' "$T5_EVIDENCE/${T5_PHASE}_device_after.txt" || check_rc=2; fi
   python - <<'PY' || check_rc=2
import json, os
from pathlib import Path
folder = Path(os.environ['T5_EVIDENCE']); phase = os.environ['T5_PHASE']
before = json.loads((folder/(phase+'_environment_before.json')).read_text())['inventory']
after = json.loads((folder/(phase+'_environment_after.json')).read_text())['inventory']
assert before['listening_tcp_ports'] == after['listening_tcp_ports'], 'Listening ports changed; inspect process inventories'
PY
 fi
 python tools/fingerprint.py --output "$T5_EVIDENCE/${T5_PHASE}_source_after.json" || check_rc=2
 if [[ "$rc" == 0 && "$check_rc" != 0 ]]; then rc=$check_rc; fi
 (set -o noclobber; printf '%s\n' "$rc" > "$T5_EVIDENCE/$T5_PHASE.exit") || rc=2
 exit "$rc"
}

require_idle_board() {
 local prefix="$1"
 for probe in 1 2 3; do
   npu-smi info > "${prefix}_${probe}.txt"
   grep -q 'No running processes found' "${prefix}_${probe}.txt" || { echo 'Board occupied; no timed run started'; exit 2; }
   if [[ "$probe" != 3 ]]; then sleep 10; fi
 done
}

phase_device_inventory() {
 T5_DEVICE_SCOPE="$1"
 : "${ASCEND_RT_VISIBLE_DEVICES:?Select one assigned runtime device}"
 : "${T5_PHYSICAL_DEVICE:?Supply the independently verified physical device ID}"
 [[ "${T5_DEVICE_CONFIRMED:-}" == 1 ]] || { echo 'Review ports, workers, and device allocation first'; exit 2; }
 npu-smi info -m > "$T5_EVIDENCE/${T5_PHASE}_mapping.txt"
 local mapping
 mapping=$(python "$T5_WRAPPERS/resolve_device_mapping.py" --input "$T5_EVIDENCE/${T5_PHASE}_mapping.txt" \
   --selector "$ASCEND_RT_VISIBLE_DEVICES" --physical "$T5_PHYSICAL_DEVICE" --output "$T5_EVIDENCE/${T5_PHASE}_mapping.json")
 read -r T5_CARD T5_CHIP <<< "$mapping"
 npu-smi info -t proc-mem -i "$T5_CARD" -c "$T5_CHIP" > "$T5_EVIDENCE/${T5_PHASE}_selected_before.txt"
 grep -Eq '^[[:space:]]*No process in device\.[[:space:]]*$' "$T5_EVIDENCE/${T5_PHASE}_selected_before.txt" || exit 2
 if [[ "$T5_DEVICE_SCOPE" == board ]]; then require_idle_board "$T5_EVIDENCE/${T5_PHASE}_idle"; fi
 python tools/preflight.py --require-soc Ascend910_9382 --output "$T5_EVIDENCE/${T5_PHASE}_environment_before.json"
 python tools/check_environment.py --input "$T5_EVIDENCE/${T5_PHASE}_environment_before.json" --accepted-driver "${T5_ACCEPTED_DRIVER:-26.1.1}"
 T5_DEVICE_STARTED=1
 verify_binaries
}

#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
# No operator build, OPP install, allocation or NPU computation.
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh" "$@"
phase_begin environment_probe
printf '%s\n' 'Official CANN environment retained; msopgen and actual ASC find_package configure passed. No operator or NPU execution.'

# PR2656 actual-header CPU checks

This external harness includes the real project headers via `-I PROJECT/xllm`:

- `core/kernels/npu/xllm_ops/t5_split_qkv_append_cache/op_kernel/t5_copy.h`
- `core/kernels/npu/xllm_ops/t5_split_qkv_append_cache/common/t5_plan.h`

It does not contain a copy of the operator algorithm. The only changes from the
previous 776-case harness are these two include paths and the port's public
names: `T5Copy.init/process`, `t5qkv::make_plan`, and the snake-case `Plan` fields.
The original CPU `kernel_operator.h` adapter remains byte-identical.

The 776 scenarios retain six small shapes, all 64 independent input/output
0/1-element offset combinations, FP16/BF16 raw bit patterns, guards, unchanged
inputs, and independent batch/head golden outputs. Eight large scenarios use
`B=16,H=16,L=2048,D=64`, with every tensor aligned or one input offset. Ordinary
DMA requires a 32-byte GM start and complete 16-element blocks; Pad checks
logical bounds and rounded UB capacity. Queue ordering is checked.

The adapter does not simulate CANN, cache aliases, hardware synchronization,
asynchrony, device concurrency or timing. Passing it does not constitute CANN
compilation, NPU correctness, memory or performance acceptance.

## Linux

Use an existing Python 3 and C++17 compiler. Select a new output directory whose
parent already exists. The runner refuses existing output directories and
checks both real source hashes before and after compilation/execution.

```bash
python3 /path/to/host_kernel/run_host_kernel.py \
  --project-root /path/to/exact-pr2656-source \
  --expected-kernel-sha256 e31fab4775acacdfb417ad55dc3fef6fce90b62e5af28b479b16cbb7c14d8dad \
  --expected-plan-sha256 dbd72a9b9585df82f83852342168237e19df73e8c7bbe29238477d07c8f93c6c \
  --reference-counts /path/to/host_kernel/a201_reference_counts.json \
  --report-dir /path/to/new-host-results
```

`summary.json` must report `passed_host_semantics_only`, `host_executed=true`,
776 scenarios and `run_all.exit=0`. The reference argument additionally compares
all eight large-case DMA/Pad records and aggregate counts with the previously
executed standalone a201 run. It does not substitute for actual execution.
For the unchanged PR baseline, supply that header's separately recorded hash
and omit the a201 reference-count argument; do not compare baseline DMA counts
with a201's expected changed paths.

## Windows

Use the same arguments with `--compile-only` and Windows paths. The installed
MSVC toolchain is located with `vswhere`; no dependencies are installed.
Windows execution is deliberately rejected because the earlier host executable
attempt was blocked by Application Control error 4551. A generated
`build_windows.bat` is a local Windows artifact, never a Linux-bound script.
The expected result is `host_compiled_not_executed`, not a semantic-test pass.

## Targeted behavior change

The accepted port leaves `aligned_fragments_`, tiling, queue use, cached-key
suffix and the L2 budget unchanged. Only per-fragment eligibility separates
G2L from L2G: a misaligned input can use padded G2L while an aligned output
uses ordinary L2G, and the reverse works for output offsets. Complete aligned
fragments retain the hoisted fast path. Short/odd fragments still use Pad.

The recorded standalone a201 large cases all have 3,086 ordinary stores and
zero padded stores. A packed-input offset produces 528 padded reads; a single
past-key or past-value offset produces 1,279 padded reads. Both dtype-bit
families have the same operation counts. These are CPU adapter call counts,
not device performance measurements.

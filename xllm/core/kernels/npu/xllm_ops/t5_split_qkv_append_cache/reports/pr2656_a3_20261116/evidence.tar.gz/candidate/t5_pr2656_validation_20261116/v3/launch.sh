#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
# Regenerate the official environment before adding task paths; never strip it afterward.
set -euo pipefail
[[ $# == 3 ]] || { echo 'Usage: launch.sh REPOSITORY EXACT_COMMIT probe|build|smoke|correctness|fixed|baseline|stability'; exit 2; }
repo=$(realpath -e -- "$1")
commit="$2"
mode="$3"
[[ "$commit" =~ ^[0-9a-f]{40}$ && $(basename -- "$repo") == "xllm_pr2656_${commit:0:12}" ]] || exit 2
case "$mode" in probe|build|smoke|correctness|fixed|baseline|stability) ;; *) exit 2 ;; esac
wrappers=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
evidence="$repo/xllm/core/kernels/npu/xllm_ops/t5_split_qkv_append_cache/artifacts/pr2656_validation_v3"
mkdir -p "$evidence"
# Remove only identified old Python/conda activation entries before official set_env.
old_venv="${VIRTUAL_ENV:-}"
old_conda="${CONDA_PREFIX:-}"
clean_path=()
IFS=: read -r -a inherited_path <<< "$PATH"
for entry in "${inherited_path[@]}"; do
 if [[ -n "$old_venv" && "$entry" == "$old_venv/bin" ]]; then continue; fi
 if [[ -n "$old_conda" && "$entry" == "$old_conda/bin" ]]; then continue; fi
 clean_path+=("$entry")
done
PATH=$(IFS=:; printf '%s' "${clean_path[*]}")
export PATH PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
unset PYTHONHOME PYTHONPATH VIRTUAL_ENV CONDA_PREFIX CONDA_DEFAULT_ENV ASCEND_CUSTOM_OPP_PATH
set +u
source /usr/local/Ascend/cann/set_env.sh
set -u
T5_CANN_ENVIRONMENT_SNAPSHOT="$evidence/${mode}_official_cann_environment.json"
export T5_CANN_ENVIRONMENT_SNAPSHOT
/usr/local/python3.12.13/bin/python3.12 -I - <<'PY'
import hashlib, json, os
from pathlib import Path
# Public build configuration only; never dump unrelated environment credentials.
explicit = {'PATH','PYTHONPATH','LD_LIBRARY_PATH','LIBRARY_PATH','LD_PRELOAD','CPATH','CPLUS_INCLUDE_PATH',
            'C_INCLUDE_PATH','PKG_CONFIG_PATH','CC','CXX','FC','TOOLCHAIN_HOME','TOOLKIT_HOME',
            'PYTHONHOME','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE'}
environment = {key:value for key,value in os.environ.items()
               if key in explicit or key.startswith(('ASC','CMAKE','CANN','TBE','TOOLCHAIN'))}
source = Path('/usr/local/Ascend/cann/set_env.sh')
record = {'source_script':str(source),'source_script_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'scope':'public_build_configuration_only','environment':environment}
with Path(os.environ['T5_CANN_ENVIRONMENT_SNAPSHOT']).open('x') as output:
    json.dump(record,output,indent=2); output.write('\n')
PY
case "$mode" in
 probe) exec bash "$wrappers/environment_probe.sh" "$repo" "$commit" ;;
 build) exec bash "$wrappers/build.sh" "$repo" "$commit" ;;
 smoke|correctness) exec bash "$wrappers/functional.sh" "$repo" "$commit" "$mode" ;;
 fixed|baseline|stability) exec bash "$wrappers/performance.sh" "$repo" "$commit" "$mode" ;;
esac

#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
# Compile/import this xLLM archive only; no NPU allocation or kernel test.
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh" "$@"
phase_begin build
for target in build "$T5_OPP_ROOT"; do
 [[ ! -e "$target" && ! -L "$target" ]] || { echo "Preserve existing output: $target"; exit 2; }
done
[[ ! -e artifacts/build_manifest.json ]] || exit 2
python - <<'PY'
import json, os
from pathlib import Path
root = Path(os.environ['TASK_ROOT'])
assert not list(root.glob('_t5_qkv*.so')), 'Preserve existing extension'
PY
python tools/preflight.py --output "$T5_EVIDENCE/build_environment.json"
python tools/check_environment.py --input "$T5_EVIDENCE/build_environment.json" --accepted-driver "${T5_ACCEPTED_DRIVER:-26.1.1}"
for script in scripts/*.sh; do bash -n "$script"; done
# Existing component build covers ACLNN, direct launcher, binding import, and C++ example.
bash scripts/build.sh
python - <<'PY'
import hashlib, json, os
from pathlib import Path
import torch, torch_npu, _t5_qkv
root, opp = Path(os.environ['TASK_ROOT']), Path(os.environ['T5_OPP_ROOT'])
assert torch.__version__ == '2.10.0+cpu' and torch_npu.__version__ == '2.10.0.post4'
assert torch_npu.version.git_version.startswith('5dd8ef3')
extensions = list(root.glob('_t5_qkv*.so'))
assert len(extensions) == 1 and Path(_t5_qkv.__file__).resolve() == extensions[0].resolve()
fingerprint = json.loads((root/'artifacts/build_manifest.json').read_text())
assert fingerprint['source_commit'] == os.environ['T5_COMMIT'] and fingerprint['worktree_status'] == 'archive verified'
files = [root/'build/direct/lib/libt5_direct.so', root/'build/examples/t5_example', extensions[0]]
files += sorted(path for path in opp.rglob('*') if path.is_file() and path.suffix in {'.so','.o','.json','.h'})
records = []
for path in files:
    data = path.read_bytes()
    records.append({'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
record = {'status':'built_and_imported','source_commit':os.environ['T5_COMMIT'],
          'repository_root':os.environ['T5_REPO'],'component':str(root),'private_opp':str(opp),
          'python_executable':os.sys.executable,'extension':str(extensions[0]),'files':records,
          'torch_npu_git_version':torch_npu.version.git_version,'npu_executed':False}
with (Path(os.environ['T5_EVIDENCE'])/'binary_manifest.json').open('x') as output:
    json.dump(record,output,indent=2); output.write('\n')
print(json.dumps(record))
PY

#!/usr/bin/env bash
set -euo pipefail
cd /workspace/t5_pr2656_validation_20261116
[[ ! -e pipeline_f990af10.exit ]] || { echo 'Preserve prior result'; exit 2; }
mkdir pipeline_f990af10.lock
trap 'rc=$?; (set -o noclobber; printf "%s\n" "$rc" > pipeline_f990af10.exit); exit "$rc"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
python3 restore_chunked_archive.py xllm_pr2656_f990af10d8cb.transfer.json 467a9dc8330b7c3247335871d1268fb247d49c2e28501a994edeed01383aefbb
python3 deploy_exact_sources.py xllm_pr2656_f990af10d8cb.tar xllm_pr2656_f990af10d8cb.manifest.json \
 --expected-commit f990af10d8cbfb7b2d1873b593bdfb7a2c73e5ce \
 --manifest-sha256 54eb0211fa6a6df29f1e0bb69ea549d6219a0b2b760a1a99ea6e5a7d04650a27
python3 host_kernel/run_host_kernel.py \
 --project-root /workspace/t5_qkv_tasks/xllm_pr2656_f990af10d8cb \
 --expected-kernel-sha256 e31fab4775acacdfb417ad55dc3fef6fce90b62e5af28b479b16cbb7c14d8dad \
 --expected-plan-sha256 dbd72a9b9585df82f83852342168237e19df73e8c7bbe29238477d07c8f93c6c \
 --reference-counts host_kernel/a201_reference_counts.json \
 --report-dir /workspace/t5_pr2656_validation_20261116/host_port_f990af10
cd v3
sha256sum --check --strict WRAPPER_SHA256SUMS.txt
for script in common.sh build.sh functional.sh performance.sh launch.sh environment_probe.sh; do bash -n "$script"; done
export ASCEND_RT_VISIBLE_DEVICES=1 T5_PHYSICAL_DEVICE=3
export T5_DEVICE_CONFIRMED=1 T5_ACCEPTED_DRIVER=26.1.1 T5_BUILD_JOBS=4
root=/workspace/t5_qkv_tasks/xllm_pr2656_f990af10d8cb
commit=f990af10d8cbfb7b2d1873b593bdfb7a2c73e5ce
bash launch.sh "$root" "$commit" probe
bash launch.sh "$root" "$commit" build
bash launch.sh "$root" "$commit" smoke
bash launch.sh "$root" "$commit" correctness
bash launch.sh "$root" "$commit" fixed
bash launch.sh "$root" "$commit" baseline
bash launch.sh "$root" "$commit" stability

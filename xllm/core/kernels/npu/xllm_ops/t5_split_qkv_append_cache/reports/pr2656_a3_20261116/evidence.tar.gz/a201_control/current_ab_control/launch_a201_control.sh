#!/usr/bin/env bash
set -euo pipefail
script=/workspace/t5_pr2656_validation_20261116/current_ab_control/run_a201_current_once.sh
[[ $(sha256sum "$script" | cut -d ' ' -f 1) == d226f2fcc9bff49faa809b344c93275b56e377c1a27f73f5b211fe511935a0d1 ]]
bash -n "$script"
export T5_DEVICE_CONFIRMED=1
exec bash "$script"

# Copyright 2026 The xLLM Authors.
# Licensed under the Apache License, Version 2.0.
"""Build the real PR2656 kernel header with the existing CPU DMA adapter."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

HARNESS = Path(__file__).resolve().parent
OPERATOR = Path('xllm/core/kernels/npu/xllm_ops/t5_split_qkv_append_cache')


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _run(command: list[str], name: str, folder: Path,
         report: dict[str, Any], timeout: int = 300) -> subprocess.CompletedProcess:
    result = subprocess.run(command, cwd=folder, capture_output=True, timeout=timeout)
    (folder / (name + '.log')).write_bytes(result.stdout + result.stderr)
    (folder / (name + '.exit')).write_text(str(result.returncode) + '\n', encoding='utf-8')
    report['stages'][name] = {'command': command, 'exit_code': result.returncode}
    if result.returncode:
        raise RuntimeError(f'{name} failed with exit {result.returncode}; see {folder / (name + ".log")}')
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, required=True)
    parser.add_argument('--expected-kernel-sha256', required=True)
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--report-dir', type=Path, required=True)
    parser.add_argument('--reference-counts', type=Path)
    parser.add_argument('--compile-only', action='store_true')
    args = parser.parse_args()
    project = args.project_root.resolve(strict=True)
    output = args.report_dir.resolve()
    if os.name == 'nt' and not args.compile_only:
        parser.error('Windows application control previously rejected host executables (4551); use --compile-only. No execution bypass is attempted.')
    output.mkdir(parents=False, exist_ok=False)
    kernel = project / OPERATOR / 'op_kernel/t5_copy.h'
    plan = project / OPERATOR / 'common/t5_plan.h'
    report: dict[str, Any] = {
        'status': 'failed_or_incomplete', 'project_root': str(project),
        'scope': 'CPU single-block byte-copy/queue semantics only; no cache aliases, concurrency, hardware synchronization or timing',
        'expected_kernel_sha256': args.expected_kernel_sha256,
        'expected_plan_sha256': args.expected_plan_sha256,
        'npu_executed': False, 'cann_compiled': False,
        'host_compiled': False, 'host_executed': False, 'stages': {},
        'python': sys.version, 'python_executable': sys.executable,
    }
    code = 1
    try:
        manifest = json.loads((HARNESS / 'harness_manifest.json').read_text(encoding='utf-8'))
        for item in manifest['files']:
            if _sha256(HARNESS / item['path']) != item['sha256']:
                raise ValueError('Operational harness hash mismatch: ' + item['path'])
        report['harness_manifest_sha256'] = _sha256(HARNESS / 'harness_manifest.json')
        if _sha256(kernel) != args.expected_kernel_sha256 or _sha256(plan) != args.expected_plan_sha256:
            raise ValueError('Actual project kernel/plan differs from requested SHA256')
        report['kernel_sha256'] = _sha256(kernel)
        report['plan_sha256'] = _sha256(plan)
        if (project / '.git').exists():
            report['repository_head'] = subprocess.check_output(
                ['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip()
            report['repository_status'] = subprocess.check_output(
                ['git', 'status', '--short'], cwd=project, text=True)
        if os.name == 'nt':
            locator = Path(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')) / 'Microsoft Visual Studio/Installer/vswhere.exe'
            installation = subprocess.check_output([
                str(locator), '-latest', '-products', '*', '-requires',
                'Microsoft.VisualStudio.Component.VC.Tools.x86.x64', '-property',
                'installationPath'], encoding='utf-8').strip()
            vcvars = Path(installation) / 'VC/Auxiliary/Build/vcvars64.bat'
            if not vcvars.is_file():
                raise ValueError('Installed MSVC environment was not found')
            report['compiler_environment'] = str(vcvars)
            executable = output / 'test_t5_copy.exe'
            batch = output / 'build_windows.bat'
            # Local Windows batch only; never transfer or execute this as a Linux script.
            lines = [
                '@echo off', f'call "{vcvars}" >nul',
                'if errorlevel 1 exit /b %errorlevel%',
                f'cl /nologo /std:c++17 /EHsc /O2 /W4 /I"{HARNESS}" /I"{project / "xllm"}" '
                f'/Fo"{output / "test_t5_copy.obj"}" /Fe"{executable}" "{HARNESS / "test_t5_copy.cpp"}"',
                'exit /b %errorlevel%', '',
            ]
            batch.write_bytes('\r\n'.join(lines).encode('utf-8'))
            _run(['cmd.exe', '/d', '/c', str(batch)], 'compile', output, report)
        else:
            compiler = shutil.which('c++')
            if not compiler:
                raise ValueError('An existing C++17 compiler is required; no installation is performed')
            _run([compiler, '--version'], 'compiler_version', output, report)
            executable = output / 'test_t5_copy'
            _run([compiler, '-std=c++17', '-O2', '-Wall', '-Wextra',
                  '-I' + str(HARNESS), '-I' + str(project / 'xllm'),
                  str(HARNESS / 'test_t5_copy.cpp'), '-o', str(executable)],
                 'compile', output, report)
        report['host_compiled'] = True
        report['executable_sha256'] = _sha256(executable)
        if args.compile_only:
            report['status'] = 'host_compiled_not_executed'
            report['execution_limitation'] = 'Windows host execution remains unattempted after the known application-control 4551 refusal.' if os.name == 'nt' else 'Caller requested compile-only.'
        else:
            result = _run([str(executable)], 'run', output, report)
            rows = [json.loads(line) for line in result.stdout.decode('utf-8').splitlines()]
            if len(rows) != 9 or rows[-1].get('status') != 'passed' or rows[-1].get('host_semantic_cases') != 776:
                raise ValueError('Missing successful 776-case actual-header summary')
            expected = {(kind, mask) for kind in ('fp16', 'bf16') for mask in (0, 1, 2, 4)}
            if len({(r.get('dtype_bits'), r.get('offset_mask')) for r in rows[:-1]}) != 8:
                raise ValueError('Duplicate large-case coverage')
            for row in rows[:-1]:
                if row.get('case') != 'large' or (row.get('dtype_bits'), row.get('offset_mask')) not in expected:
                    raise ValueError('Incorrect large-case coverage')
                if any(type(row.get(k)) is not int or row[k] < 0 for k in ('dma_read', 'pad_read', 'dma_write', 'pad_write')):
                    raise ValueError('Invalid DMA/Pad counter')
            if rows[-1].get('npu_executed') is not False or rows[-1].get('cann_compiled') is not False:
                raise ValueError('CPU adapter must not claim hardware validation')
            if args.reference_counts:
                reference = json.loads(args.reference_counts.read_text(encoding='utf-8'))
                if reference['records'] != rows:
                    raise ValueError('Actual port DMA/Pad records differ from the selected recorded standalone reference')
                report['reference_counts_sha256'] = _sha256(args.reference_counts)
            report.update(status='passed_host_semantics_only', host_executed=True, records=rows)
        if _sha256(kernel) != args.expected_kernel_sha256 or _sha256(plan) != args.expected_plan_sha256:
            raise ValueError('Project source changed during the host check')
        code = 0
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        report.update(status='failed_or_incomplete', error=f'{type(error).__name__}: {error}')
    report['exit_code'] = code
    with (output / 'summary.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    (output / 'run_all.exit').write_text(str(code) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'report': str(output / 'summary.json'), 'exit_code': code}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())

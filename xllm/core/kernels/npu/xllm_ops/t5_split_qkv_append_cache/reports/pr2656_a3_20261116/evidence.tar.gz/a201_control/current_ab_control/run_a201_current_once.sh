#!/usr/bin/env bash
# One discriminating current-condition control of the preserved a201 binaries.
# No rebuild, no source changes, no retries, no writes to old reports.
set -euo pipefail
[[ $# == 0 ]] || exit 2
task_ops=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ "$task_ops" == /workspace/t5_pr2656_validation_20261116/current_ab_control ]] || exit 2
task_wrapper="$task_ops/run_a201_current_once.sh"
task_evidence="$task_ops/evidence_a201_once"
task_exit="$task_ops/a201_once.exit"
[[ ! -e "$task_evidence" && ! -L "$task_evidence" && ! -e "$task_exit" && ! -e "$task_ops/a201_once.log" ]] || exit 2
mkdir "$task_ops/a201_once.lock"
trap 'rc=$?; (set -o noclobber; printf "%s\n" "$rc" > "$task_exit"); exit "$rc"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
mkdir "$task_evidence"
set -o noclobber
exec > "$task_ops/a201_once.log" 2>&1
set +o noclobber
task_venv=/workspace/t5_qkv_tasks/venv_t5_py312_torch210_20261116_offline_v3
task_deployment=/workspace/t5_qkv_tasks/t5_qkv_a2013d56db4f
[[ "${T5_DEVICE_CONFIRMED:-}" == 1 ]] || { echo 'Review ports/workers and arrange whole-board idle before launch'; exit 2; }
old_venv="${VIRTUAL_ENV:-}"
old_conda="${CONDA_PREFIX:-}"
clean_path=()
IFS=: read -r -a inherited_path <<< "$PATH"
for entry in "${inherited_path[@]}"; do
 if [[ -n "$old_venv" && "$entry" == "$old_venv/bin" ]]; then continue; fi
 if [[ -n "$old_conda" && "$entry" == "$old_conda/bin" ]]; then continue; fi
 clean_path+=("$entry")
done
PATH=$(IFS=:; printf '%s' "${clean_path[*]}")
export PATH PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
unset PYTHONHOME PYTHONPATH VIRTUAL_ENV CONDA_PREFIX CONDA_DEFAULT_ENV ASCEND_CUSTOM_OPP_PATH
unset T5_OPP_ROOT TASK_QUEUE_ENABLE T5_ACLNN_EXECUTOR_REUSE
set +u
source /usr/local/Ascend/cann/set_env.sh
set -u
: "${ASCEND_HOME_PATH:?Official CANN environment is required}"
[[ -z "${TASK_QUEUE_ENABLE+x}" && -z "${T5_ACLNN_EXECUTOR_REUSE+x}" ]] || exit 2
export PATH="$task_venv/bin:$PATH" VIRTUAL_ENV="$task_venv"
# Source performs the unchanged full archive hash check; do not call its phases.
source "$task_deployment/scripts/phase_common.sh"
[[ "$TASK_ROOT" == "$task_deployment" ]] || exit 2
export ASCEND_RT_VISIBLE_DEVICES=1 T5_PHYSICAL_DEVICE=3 T5_FUNCTIONAL_DEVICE_SCOPE=board
export ASCEND_CUSTOM_OPP_PATH="$T5_OPP_ROOT/vendors/t5qkv"
export PYTHONPATH="$TASK_ROOT:$TASK_ROOT/reference${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH="$TASK_ROOT/build/direct/lib:$T5_OPP_ROOT/vendors/t5qkv/op_api/lib:$task_venv/lib/python3.12/site-packages/torch/lib:$task_venv/lib/python3.12/site-packages/torch_npu/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export task_venv task_wrapper task_evidence
sha256sum "$task_wrapper"

task_verify_identity() {
  python - "$1" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
root = Path(os.environ['TASK_ROOT'])
folder = root / 'artifacts/validation'
evidence = Path(os.environ['task_evidence'])
venv = Path(os.environ['task_venv'])
stage = sys.argv[1]
def load(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = load(root / 'DEPLOYMENT_MANIFEST.json')
commit = manifest['commit']
if commit != 'a2013d56db4ff8367160b157335d2ff670aad411':
    raise SystemExit('Unexpected exact source commit')
if root.name != 't5_qkv_' + commit[:12] or manifest['prefix'] != root.name:
    raise SystemExit('Deployment path/commit mismatch')
for item in manifest['files']:
    path = root / Path(item['path']).relative_to(root.name)
    if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
        raise SystemExit('Tracked source changed: ' + str(path))
if Path(sys.prefix) != venv or (venv / 'setup.exit').read_text().strip() != '0':
    raise SystemExit('Private runtime setup is not verified')
for name in ('native_build', 'native_smoke_20261116', 'build_full', 'smoke_phase', 'correctness_phase'):
    if (folder / (name + '.exit')).read_text().strip() != '0':
        raise SystemExit('Required successful stage: ' + name)
binding = load(folder / 'binding_import.json')
gate = load(folder / 'binding_gate.json')
if (binding['status'] != 'import_passed' or binding['python_executable'] != str(venv / 'bin/python')
        or gate['status'] != 'passed' or gate['source_commit'] != commit
        or gate['python_executable'] != str(venv / 'bin/python')):
    raise SystemExit('Binding receipt does not match this source/runtime')
extension = Path(binding['extension'])
if extension.parent != root or list(root.glob('_t5_qkv*.so')) != [extension]:
    raise SystemExit('Unexpected extension origin/count')
if extension.stat().st_size != binding['bytes'] or digest(extension) != binding['sha256']:
    raise SystemExit('Binding binary changed')
opp = Path(os.environ['T5_OPP_ROOT'])
if (opp != Path.home() / '.local' / root.name or opp.resolve(strict=True) != opp
        or os.environ['ASCEND_CUSTOM_OPP_PATH'] != str(opp / 'vendors/t5qkv')):
    raise SystemExit('Expected the sole private OPP for this exact deployment')
native = load(folder / 'native_binary_manifest.json')
if native['source_commit'] != commit or native['private_opp'] != str(opp):
    raise SystemExit('Native manifest source/OPP mismatch')
expected = {root / 'build/direct/lib/libt5_direct.so', root / 'build/examples/t5_example'}
expected.update(p for p in opp.rglob('*') if p.is_file() and p.suffix in {'.so', '.o', '.json', '.h'})
seen = set()
for item in native['files']:
    path = Path(item['path'])
    if path not in expected or path in seen or not (path.resolve(strict=True).is_relative_to(opp) or path.resolve(strict=True).is_relative_to(root / 'build')):
        raise SystemExit('Unexpected, redirected or duplicate native file: ' + str(path))
    if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
        raise SystemExit('Native file changed: ' + str(path))
    seen.add(path)
if seen != expected:
    raise SystemExit('Native manifest file coverage changed')
receipts = [folder / 'binding_import.json', folder / 'binding_gate.json', folder / 'native_binary_manifest.json',
            venv / 'metadata_verified.json', venv / 'install-report.json']
for mode in ('smoke', 'correctness'):
    base = folder / ('functional_' + mode)
    summary, identity = load(base / 'summary.json'), load(base / 'identity.json')
    if (summary['status'] != 'passed_functional_only' or summary['phase'] != mode
            or summary['source_commit'] != commit or summary['npu_executed'] is not True
            or summary['performance_executed'] is not False or identity['source_commit'] != commit
            or identity['extension_sha256'] != binding['sha256'] or identity['physical_device'] != 3
            or identity['runtime_selector'] != 1 or identity['logical_device'] != 0):
        raise SystemExit('Functional receipt does not match this source/binary/device: ' + mode)
    receipts += [base / 'summary.json', base / 'identity.json']
    for name in ('source_before.json', 'source_after.json'):
        fingerprint = load(base / name)
        if fingerprint['source_commit'] != commit or fingerprint['worktree_status'] != 'archive verified':
            raise SystemExit('Functional source receipt mismatch: ' + mode + '/' + name)
    for name, count in summary['counts'].items():
        report = load(folder / name)
        rows = report['cases'] if name == 'public_accuracy.json' else report['records']
        if report['status'] != 'passed' or report['npu_executed'] is not True or len(rows) != count:
            raise SystemExit('Functional report no longer matches its passing receipt: ' + name)
        receipts.append(folder / name)
public = load(root / 'reference/case.json')
ids = [c['case_name'] for c in public if c.get('performance') is True]
if len(ids) != 10 or len(set(ids)) != 10 or set(ids) != set(load(root / 'reference/coverage_requirements.json')['performance_case_ids']):
    raise SystemExit('Expected the original ten fixed performance cases')
report = {'source_commit': commit, 'deployment_manifest_sha256': digest(root / 'DEPLOYMENT_MANIFEST.json'),
          'wrapper_sha256': digest(Path(os.environ['task_wrapper'])), 'extension_sha256': binding['sha256'],
          'native_files_verified': len(seen), 'private_opp': str(opp), 'python_executable': sys.executable,
          'physical_device': 3, 'runtime_selector': 1, 'logical_device': 0,
          'case_ids': ids, 'runtime_controls': {key: os.environ.get(key) for key in ('TASK_QUEUE_ENABLE', 'T5_ACLNN_EXECUTOR_REUSE')},
          'receipt_sha256': {str(p): digest(p) for p in receipts}}
if stage == 'post' and report != load(evidence / 'identity_pre.json'):
    raise SystemExit('Source, binary, wrapper or prerequisite evidence changed during measurement')
with (evidence / ('identity_' + stage + '.json')).open('x') as out:
    json.dump(report, out, indent=2); out.write('\n')
print(json.dumps(report))
PY
}


task_finish() {
 local task_rc=$? task_run_rc identity_rc inventory_rc smi_rc clearance_rc
 task_run_rc=$task_rc
 trap - EXIT
 set +e
 task_verify_identity post > "$task_evidence/identity_post.log" 2>&1
 identity_rc=$?
 python tools/preflight.py --output "$task_evidence/environment_after.json" > "$task_evidence/environment_after.log" 2>&1
 inventory_rc=$?
 npu-smi info > "$task_evidence/device_after.txt" 2>&1
 smi_rc=$?
 python - <<'PY' > "$task_evidence/clearance.log" 2>&1
import json, os
from pathlib import Path
folder = Path(os.environ['task_evidence'])
before = json.loads((folder/'environment_before.json').read_text())['inventory']
after = json.loads((folder/'environment_after.json').read_text())['inventory']
assert before['listening_tcp_ports'] == after['listening_tcp_ports'], 'Listening ports changed'
assert 'No running processes found' in (folder/'device_after.txt').read_text(), 'Board is not clear'
print('Ports unchanged; board clear. Before/after worker process inventories retained.')
PY
 clearance_rc=$?
 if [[ "$task_rc" == 0 && ( "$identity_rc" != 0 || "$inventory_rc" != 0 || "$smi_rc" != 0 || "$clearance_rc" != 0 ) ]]; then task_rc=2; fi
 printf 'run_exit=%s identity_exit=%s inventory_exit=%s smi_exit=%s clearance_exit=%s final_exit=%s\n' "$task_run_rc" "$identity_rc" "$inventory_rc" "$smi_rc" "$clearance_rc" "$task_rc"
 (set -o noclobber; printf '%s\n' "$task_rc" > "$task_exit")
 exit "$task_rc"
}
trap task_finish EXIT
task_verify_identity pre > "$task_evidence/identity_pre.log" 2>&1
python tools/preflight.py --static > "$task_evidence/static.log" 2>&1
python tools/preflight.py --require-soc Ascend910_9382 --output "$task_evidence/environment_before.json" > "$task_evidence/environment_before.log" 2>&1
python tools/check_environment.py --input "$task_evidence/environment_before.json" --accepted-driver 26.1.1
python - <<'PY' > "$task_evidence/current_environment.json"
import hashlib, json, os
from pathlib import Path
root = Path(os.environ['TASK_ROOT'])
port = Path('/workspace/t5_qkv_tasks/xllm_pr2656_f990af10d8cb/xllm/core/kernels/npu/xllm_ops/t5_split_qkv_append_cache')
names = ('reference/benchmark.py','reference/check_performance.py','reference/case.json','reference/performance_targets.json')
hashes = {}
for name in names:
    left, right = (root/name).read_bytes(), (port/name).read_bytes()
    assert left == right, 'Frozen timing/acceptance inputs differ from current port: '+name
    hashes[name] = hashlib.sha256(left).hexdigest()
keys = ('TASK_QUEUE_ENABLE','T5_ACLNN_EXECUTOR_REUSE')
assert all(key not in os.environ for key in keys), 'Runtime controls must remain unset'
environment = {key:os.environ.get(key) for key in ('PATH','PYTHONPATH','LD_LIBRARY_PATH','CMAKE_PREFIX_PATH','ASCEND_HOME_PATH','ASCEND_OPP_PATH','ASCEND_CUSTOM_OPP_PATH','ASCEND_RT_VISIBLE_DEVICES','T5_OPP_ROOT','T5_PHYSICAL_DEVICE') + keys}
print(json.dumps({'hypothesis':'Preserved a201 binaries under current same-host conditions; distinguish current conditions from port-specific changes',
                  'source_commit':'a2013d56db4ff8367160b157335d2ff670aad411',
                  'comparison_commit':'f990af10d8cbfb7b2d1873b593bdfb7a2c73e5ce',
                  'benchmark_invocations':1,'logical_device':0,'environment':environment,
                  'frozen_reference_sha256':hashes},indent=2))
PY
npu-smi info -m > "$task_evidence/device_mapping.txt"
mapping=$(python tools/resolve_device_mapping.py --input "$task_evidence/device_mapping.txt" --selector 1 --physical 3 --output "$task_evidence/device_mapping.json")
read -r task_card task_chip <<< "$mapping"
npu-smi info -t proc-mem -i "$task_card" -c "$task_chip" > "$task_evidence/selected_before.txt"
grep -Eq '^[[:space:]]*No process in device\.[[:space:]]*$' "$task_evidence/selected_before.txt" || exit 2
for probe in 1 2 3; do
 npu-smi info > "$task_evidence/device_idle_$probe.txt"
 grep -q 'No running processes found' "$task_evidence/device_idle_$probe.txt" || { echo 'Board occupied; no benchmark started'; exit 2; }
 if [[ "$probe" != 3 ]]; then sleep 10; fi
done
# Exactly one unchanged benchmark; always run the CPU checker, even on failure.
set -o noclobber
set +e
python reference/benchmark.py --device 0 --solution-file "$TASK_ROOT/solution.py" --report "$task_evidence/performance.json" > "$task_evidence/performance.log" 2>&1
task_benchmark_rc=$?
printf '%s\n' "$task_benchmark_rc" > "$task_evidence/benchmark.exit"
python reference/check_performance.py --report "$task_evidence/performance.json" --output "$task_evidence/performance_acceptance.json" > "$task_evidence/performance_acceptance.log" 2>&1
task_checker_rc=$?
printf '%s\n' "$task_checker_rc" > "$task_evidence/checker.exit"
set -e
printf 'benchmark_exit=%s checker_exit=%s\n' "$task_benchmark_rc" "$task_checker_rc"
[[ "$task_benchmark_rc" == 0 ]] || exit "$task_benchmark_rc"
[[ "$task_checker_rc" == 0 ]] || exit "$task_checker_rc"

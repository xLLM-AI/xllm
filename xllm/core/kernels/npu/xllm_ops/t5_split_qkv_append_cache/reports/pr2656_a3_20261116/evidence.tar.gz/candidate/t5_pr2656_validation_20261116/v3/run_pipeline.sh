#!/usr/bin/env bash
set -euo pipefail
cd /workspace/t5_pr2656_validation_20261116/v3
[[ ! -e pipeline.exit ]] || { echo 'Preserve existing pipeline result'; exit 2; }
mkdir pipeline.lock
trap 'rc=$?; (set -o noclobber; printf "%s\n" "$rc" > pipeline.exit); exit "$rc"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
for item in build.sh functional.sh performance.sh resolve_device_mapping.py; do
 [[ ! -e "$item" ]] || exit 2
 cp -- "../$item" "$item"
done
sha256sum --check --strict WRAPPER_SHA256SUMS.txt
for script in common.sh build.sh functional.sh performance.sh launch.sh environment_probe.sh; do bash -n "$script"; done
[[ $(cat ../host_port_38a01af5/run_all.exit) == 0 ]] || exit 2
export ASCEND_RT_VISIBLE_DEVICES=1 T5_PHYSICAL_DEVICE=3
export T5_DEVICE_CONFIRMED=1 T5_ACCEPTED_DRIVER=26.1.1 T5_BUILD_JOBS=4
root=/workspace/t5_qkv_tasks/xllm_pr2656_38a01af549b6
commit=38a01af549b66302b623626014c43a4b3fe41666
bash launch.sh "$root" "$commit" probe
bash launch.sh "$root" "$commit" build
bash launch.sh "$root" "$commit" smoke
bash launch.sh "$root" "$commit" correctness
bash launch.sh "$root" "$commit" fixed
bash launch.sh "$root" "$commit" baseline
bash launch.sh "$root" "$commit" stability

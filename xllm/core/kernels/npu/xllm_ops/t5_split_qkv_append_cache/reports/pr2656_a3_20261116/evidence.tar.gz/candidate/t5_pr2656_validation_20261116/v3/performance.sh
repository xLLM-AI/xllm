#!/usr/bin/env bash
# Copyright 2026 The xLLM Authors. Apache-2.0.
# Only the existing frozen benchmark/checker and existing allocating baseline.
set -euo pipefail
[[ $# == 3 ]] || { echo 'Usage: performance.sh REPOSITORY EXACT_COMMIT fixed|baseline|stability'; exit 2; }
mode="$3"
case "$mode" in fixed|baseline|stability) ;; *) exit 2 ;; esac
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh" "$1" "$2"
case "$mode" in
 fixed) phase_begin fixed correctness ;;
 baseline) phase_begin baseline fixed ;;
 stability) phase_begin stability baseline ;;
esac
phase_device_inventory board
if [[ "$mode" == fixed ]]; then
 [[ ! -e reports/performance.json && ! -e reports/performance_acceptance.json ]] || exit 2
 rc=0
 python reference/benchmark.py --solution-file "$TASK_ROOT/solution.py" --report reports/performance.json > reports/performance.log 2>&1 || rc=$?
 printf '%s\n' "$rc" > "$T5_EVIDENCE/fixed_benchmark.exit"
 [[ "$rc" == 0 ]] || exit "$rc"
 python reference/check_performance.py --report reports/performance.json --output reports/performance_acceptance.json
elif [[ "$mode" == baseline ]]; then
 [[ ! -e reports/baseline_comparison.json && ! -e reports/coverage_acceptance.json ]] || exit 2
 # Separate existing allocating views/cat comparison; not a fixed-limit substitute.
 python tests/compare_baseline.py --report reports/baseline_comparison.json > reports/baseline_comparison.log 2>&1
 python tools/check_coverage.py --reports reports
else
 [[ $(cat "$T5_EVIDENCE/fixed.exit") == 0 ]] || exit 2
 python - <<'PY'
import hashlib, json, os
from pathlib import Path
report = json.loads(Path('reports/coverage_acceptance.json').read_text())
assert report['status'] == 'passed'
folder = Path(os.environ['T5_EVIDENCE'])
files = {name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ('reference/benchmark.py','reference/check_performance.py','reference/case.json','reference/performance_targets.json')}
with (folder/'stability_predeclared.json').open('x') as output:
    json.dump({'source_commit':os.environ['T5_COMMIT'],'fresh_processes':5,'stop_at_first_failure':True,
               'frozen_files':files,'no_retry_to_pass':True},output,indent=2); output.write('\n')
PY
 mkdir "$T5_EVIDENCE/repeated_performance"
 for run in 1 2 3 4 5; do
   prefix="$T5_EVIDENCE/repeated_performance/run_$run"
   require_idle_board "${prefix}_idle"
   verify_source
   verify_binaries
   python tools/preflight.py --require-soc Ascend910_9382 --output "${prefix}_environment.json" > "${prefix}_environment.log"
   rc=0
   python reference/benchmark.py --solution-file "$TASK_ROOT/solution.py" --report "${prefix}.json" > "${prefix}.log" 2>&1 || rc=$?
   printf '%s\n' "$rc" > "${prefix}.exit"
   npu-smi info > "${prefix}_device_after.txt"
   [[ "$rc" == 0 ]] || exit "$rc"
   grep -q 'No running processes found' "${prefix}_device_after.txt" || exit 2
   rc=0
   python reference/check_performance.py --report "${prefix}.json" --output "${prefix}_acceptance.json" > "${prefix}_acceptance.log" 2>&1 || rc=$?
   printf '%s\n' "$rc" > "${prefix}_acceptance.exit"
   [[ "$rc" == 0 ]] || exit "$rc"
 done
fi
